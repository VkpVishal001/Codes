In this folder, we keep all the Resources ("res") required for the project. 
Some important config files are also stored here.
For resource credits, checkout credits.txt

ALL FILES AND FOLDERS, ANYTHING UNDER THIS DIRECTORY IS VERY IMPORTANT FOR MY-PYCHESS TO WORK.
DO NOT DELETE ANYTHING.

img - Folder to store images
savedGames - Folder to store saved games
sounds - Folder to store sound files
stockfish - Folder to store stockfish executable and config file
texts - Folder to store a few texts

Asimov.otf - Font file
preferences.txt - config file to store user preferences and settings
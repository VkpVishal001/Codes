This folder is a place to store stockfish chess engine related stuff.
Some stockfish config files are stored here.

If you are searching for a place to put the stockfish executable, navigate inside
the build directory in this directory.

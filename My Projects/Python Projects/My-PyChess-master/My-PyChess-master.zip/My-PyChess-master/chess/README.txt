In this folder we keep all scripts to handle chess gameplay.
Each file has a main() function, which when called, handles the chess gameplay

multiplayer.py - Handles multiplayer chess
singlepayer.py - Handles singleplayer chess with stockfish chess engine
mysingleplayer.py - Handles singleplayer chess with a chess engine written in python(minimax-algorithm)
online.py - Handles online chess

For more docmentation of the variables used and such, check docs.txt
This folder is a place to store some external scripts. These scripts are essential for PyChess. They are general purpose modules - you can use them too.

pyBox.py - Defines a class for textbox in pygame
pyFish.py - Define a class to interface with the stockfish chess engine